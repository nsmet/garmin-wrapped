export default {plugins:{}};
